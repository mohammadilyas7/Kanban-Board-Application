package com.task.service;

import com.task.exception.SpaceNotFoundException;
import com.task.model.Space;
import com.task.repository.SpaceRepository;
import com.task.repository.TaskRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class SpaceService {
    @Autowired
    SpaceRepository spaceRepository;
    @Autowired
    TaskRepository taskRepository;
    public Space createSpace(Space space,String email) throws SpaceNotFoundException{
//       Space space1 = spaceRepository.findByEmail(space.getSpaceName());
        Space space1 = null;
        space1.setSpaceName(space.getSpaceName());
        space1.setEmail(email);
        space1.setTaskList(null);
        return  spaceRepository.save(space1);
    }

    public List<Space> getAllSpace() {
        return spaceRepository.findAll();
    }

    public String deleteByIdAndEmail(String email, String spaceName) throws SpaceNotFoundException {
        Space space = spaceRepository.findByEmail(email);
            if (space.getEmail() != null){
                if (space.getEmail().equals(email) && space.getSpaceName().equals(spaceName)){
                    System.out.println("******** deleteByIdAndEmail *********");
                    System.out.println(space.getEmail().equals(email) +" "+ space.getSpaceName().equals(spaceName));
                    spaceRepository.delete(space);
                    return "Space Deleted Successfully";
                }
            }
        throw new SpaceNotFoundException("Space Not Found");
    }

    //genrate the spaceId
    public static long genratedSpaceId(Space space){
        long min = 111111111111l;
        long max = 999999999999l;
        long id =(long) (Math.random()*(max-min)+min);
        System.out.println("\ngenerate the Id : "+id);
        return id;
    }

//|| (list.get(i).getSpaceName().equalsIgnoreCase(space.getSpaceName()) && list.get(i).getSpaceId().equals(space.getSpaceId()) )
}