package com.task.proxy;

public interface UserProxy {
}
